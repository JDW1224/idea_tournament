import os
import serial

arduino = serial.Serial('COM3', 9600)

import pyotp
otp_secret = os.environ["OTP_SECRET"]
otp_account = os.environ.get("OTP_ACCOUNT_NAME", "user@example.com")
otp_issuer = os.environ.get("OTP_ISSUER", "Secure App")
totp = pyotp.TOTP(otp_secret)
print("Current OTP:", totp.now())

a = pyotp.totp.TOTP(otp_secret).provisioning_uri(name=otp_account, issuer_name=otp_issuer)
b = pyotp.hotp.HOTP(otp_secret).provisioning_uri(name=otp_account, issuer_name=otp_issuer, initial_count=0)

while(True):

    c=arduino.readline()

    c = c.decode()

    if(len(c)>=6):
        print(c)
        break
password = int(c.strip())
otp = int(totp.now())
if(password == otp):
    print("열렸습니다")
else:
    print(otp)
    print("닫혔습니다.")