
#include <Servo.h>
String sig;
char Ard1[5]={0};

char check[1];
int value_1=0;
Servo servo;
int value = 0;

void setup()
{
  Serial.begin(9600);
  servo.attach(8);
  servo.write(180);
  pinMode(7,OUTPUT); // LED 연결
}

void loop()
{ 
  /* 문자열로 저장*/
  int flag = 0;
  while(Serial.available()) 
   {
     char wait = Serial.read();
     sig.concat(wait);
   } 
  
    /* 입력 문자열 슬라이싱 */
    sig.substring(0,1).toCharArray(check,2);

    if(check[0] == 'Q')
      {
      if (sig.length()==5)
        {
          sig.substring(1,5).toCharArray(Ard1,5);
          
          value_1 = atoi(Ard1);
          
          sig = "";
        }
       else if (sig.length()>5)
        {sig = "";}
       }
     else if (check[0] != 'Q')
      {sig = "";}

     /* 수신 확인*/
    if(value_1 == 1234)
      {
        flag = 1;
      }

    if(flag == 1)     
  {
    for(value=180;value>90;value-=0.5)
     { 
       servo.write(value);
       delay(20);
     }
     flag = 0;
     value_1 = 0;
  }else{
    servo.write(180);
    
  }
}
